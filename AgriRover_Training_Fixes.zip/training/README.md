# Training

Model training runs on Google Colab (free T4 GPU, BOM #110). Each notebook
covers the full pipeline from dataset loading to Edge TPU compilation.

## Hardware Requirements

- Google Colab with **T4 GPU** runtime (free tier sufficient)
- ~10 GB Google Drive space for datasets and checkpoints
- Edge TPU compiler runs within Colab (installed automatically)

## Notebooks

### 1. `disease_classification.ipynb`

Fine-tunes a MobileNetV2 model on the PlantVillage dataset for crop disease
classification (38 classes across 14 crops).

**Pipeline:**
- Loads PlantVillage from `tensorflow_datasets`
- Applies augmentation (RandomFlip, RandomRotation, RandomZoom, RandomContrast)
- Two-phase training: frozen base feature extraction, then top-layer fine-tuning
- Evaluates with confusion matrix and classification report
- Exports float16 and full INT8 quantized TFLite models
- Compiles INT8 model for Coral Edge TPU

**Output files:**
| File | Description | Deploy to |
|------|-------------|-----------|
| `disease_model_float16.tflite` | CPU fallback model | `models/disease_model_float16.tflite` |
| `disease_model_quant_edgetpu.tflite` | Edge TPU model | `models/disease_model_quant_edgetpu.tflite` |

### 2. `weed_detection.ipynb`

Trains a YOLOv8n bounding-box model on the public Crop and Weed Detection
dataset (2 classes: `crop`, `weed`). The original DeepWeeds dataset is not
used because it supplies image-level classification labels, not bounding boxes.

**Pipeline:**
- Downloads the 1,300-image public Kaggle dataset without a placeholder API key
- Creates deterministic 80/10/10 train/validation/test splits
- Validates every YOLO annotation, class ID, normalized box, and split
- Trains YOLOv8n with augmentation (mosaic, mixup, HSV)
- Validates with mAP50, mAP50-95, precision, and recall metrics
- Exports calibrated full-INT8 CPU TFLite and Coral Edge TPU variants
- Verifies NHWC input and raw YOLO output compatibility with the Pi decoder

**Output files:**
| File | Description | Deploy to |
|------|-------------|-----------|
| `weed_model_quant.tflite` | INT8 CPU fallback | `models/weed_model_quant.tflite` |
| `weed_model_quant_edgetpu.tflite` | Edge TPU model | `models/weed_model_quant_edgetpu.tflite` |
| `weed_labels.txt` | `crop`, `weed` in model order | `models/weed_labels.txt` |

### 3. `obstacle_detection.ipynb`

Trains a YOLOv8n model for real-time obstacle detection with 7 classes:
person, vehicle, animal, rock, stump, fence, ditch.

**Pipeline:**
- Uploads one prepared YOLO dataset ZIP and verifies its exact seven-class order
- Rejects missing labels, malformed rows, invalid boxes, empty splits, and absent classes
- Trains from COCO pretrained weights with augmentation tuned for outdoor scenes
- Evaluates overall and per-class mAP metrics
- Exports calibrated full-INT8 CPU TFLite and Coral Edge TPU variants
- Verifies tensor compatibility with `pi/ai/yolo_tflite.py`
- Requires real on-device benchmarking instead of claiming Coral FPS from a Colab GPU

**Output files:**
| File | Description | Deploy to |
|------|-------------|-----------|
| `obstacle_model_quant.tflite` | INT8 CPU fallback | `models/obstacle_model_quant.tflite` |
| `obstacle_model_quant_edgetpu.tflite` | Edge TPU model | `models/obstacle_model_quant_edgetpu.tflite` |
| `obstacle_labels.txt` | Seven labels in model order | `models/obstacle_labels.txt` |

## Datasets

- **PlantVillage** - 54,000+ images, 14 crops, 38 disease classes (disease model)
- **Crop and Weed Detection Data with Bounding Boxes** - 1,300 images, `crop`/`weed` boxes (starter weed model)
- **Custom obstacles** - User-collected + legally usable public subsets (obstacle model)

## Workflow

1. Open the notebook in Google Colab (set runtime to GPU/T4).
2. Run all cells sequentially; the notebooks validate data before starting training.
3. Download both the INT8 CPU fallback and Edge TPU compiled `.tflite` files plus labels.
4. Copy artifacts to `models/` on the Raspberry Pi (see `models/README.md`).
5. Benchmark on the actual Pi/Coral and complete the safety checks in `TRAIN_WEED_AND_OBSTACLE_MODELS.md`.

## Model-to-Module Mapping

| Model file | Pi module | Class |
|------------|-----------|-------|
| `models/disease_model_quant_edgetpu.tflite` | `pi/ai/disease_detection.py` | `DiseaseClassifier` |
| `models/weed_model_quant_edgetpu.tflite` | `pi/ai/weed_detection.py` | `WeedDetector` |
| `models/obstacle_model_quant_edgetpu.tflite` | `pi/ai/obstacle_detection.py` | `ObstacleDetector` |
